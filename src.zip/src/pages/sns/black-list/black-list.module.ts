import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BlackListPage } from './black-list';

@NgModule({
  declarations: [
    BlackListPage,
  ],
  imports: [
    IonicPageModule.forChild(BlackListPage),
  ],
})
export class BlackListPageModule {}
