import {Component, ViewChild} from '@angular/core';
import {IonicPage, NavController, NavParams} from 'ionic-angular';
import {Events, Content, TextInput} from 'ionic-angular';
import {ChatMessage, UserInfo} from "../../../providers/MainCtrl";
import {CommonModel} from "../../../providers/CommonModel";
import {MainCtrl} from "../../../providers/MainCtrl";
import {ThirdPartyApiProvider} from "../../../providers/third-party-api";
import {HttpService} from "../../../providers/HttpService";
import {HttpConfig} from "../../../providers/HttpConfig";

declare var RongIMLib: any;
declare var RongIMClient: any;
declare var MessageType: any;
declare var TextMessage: any;

@IonicPage()
@Component({
    selector: 'page-chat',
    templateUrl: 'chat.html',
})
export class ChatPage {

    @ViewChild(Content) content: Content;
    @ViewChild('chat_input') messageInput: TextInput;
    msgList: ChatMessage[] = [];
    user: UserInfo;
    toUser: UserInfo;
    editorMsg = '';
    showEmojiPicker = false;
    isScrolling = false;
    // 下拉加载
    pageData = {
        pageNo: 1,
        rows: 10,
        loadEnd: false,
        clist: undefined,
        scrollTop: 0
    }

    constructor(public navParams: NavParams,
                public mainCtrl: MainCtrl,
                public events: Events, public commonModel: CommonModel, public thirdPartyApi: ThirdPartyApiProvider,
                public httpService: HttpService, public httpConfig: HttpConfig,public navCtrl:NavController) {
        // Get mock user information
        //获取当前用户信息
        this.mainCtrl.getChatUserInfo()
            .then((res) => {
                this.user = res
                console.log("当前用户信息：", this.user);
            });
        // Get the navParams toUserId parameter、
        this.toUser = {
            id: navParams.get('toUserId'),
            name: navParams.get('toUserName'),
            avatar: navParams.get('headPic')
        };
        console.log("聊天好友信息：", this.toUser);

        //订阅新消息事件
        this.events.subscribe('recMsg', (msg) => {
            console.log("聊天界面接收到消息事件：", msg);
            msg = JSON.parse(msg);
            //   如果是当前窗口好友发送的则添加
            if (msg.senderUserId == this.toUser.id) {
                // 废弃
                let newMsg: ChatMessage = {
                    messageId: msg.messageId,
                    userId: msg.senderUserId,
                    userName: msg.userName,
                    userAvatar: msg.headPic,
                    toUserId: msg.beUserId,
                    time: msg.updateTime,
                    message: msg.recentlyChat,
                    // status: 'pending'
                    status: 'success'
                };
                let mType=this.getMsgType(msg.recentlyChat);
                let msgObj= {
                        "headPic": msg.headPic,
                        "message": msg.recentlyChat,
                        "me": false,
                    "messageType":mType,
                    timestamp:msg.updateTime,
                    userId: this.user.id,
                    toUserId: this.toUser.id
                    };

                // this.pushNewMsg(newMsg);
                this.addNewMsg(msgObj);
            //    标记为已读
                this.setReadStatus();
            }
        })
        // 标记为已读
        this.setReadStatus();
        // 从服务器获取聊天记录
        this.getHistoryChat();
    }

    loadMore(InfiniteScroll) {
        console.log("加载更多数据");
        this.pageData.loadEnd = false;
        this.getHistoryChat(InfiniteScroll);
    }
    seeUserInfo(msg){
        let nickName=msg.me?this.user.name:this.toUser.name;
        this.navCtrl.push("SnsUserInfoPage",{
            userId:msg.userId,
            nickName:nickName
        })
    }
    /**
     * 设置消息读取状态
     */
    setReadStatus(){
        let url = this.httpConfig.host.org + "/sns/history/" +  this.toUser.id;
        this.httpService.put(url).subscribe(data => {
            if (data.success) {
                console.log("更新消息读取状态成功！");
            } else {
                console.log("更新消息读取状态失败：", data.msg);
            }
        })
    }
    //从服务器获取聊天记录
    getHistoryChat(InfiniteScroll?) {

        if (this.pageData.loadEnd) {
            InfiniteScroll && InfiniteScroll.complete();
            return false;
        }
        if (this.isScrolling) {//正在加载中
            return;
        }
        this.isScrolling = true;
        let url = this.httpConfig.host.org + "/sns/history/" + this.toUser.id;
        let reqData = {
            pageNo: this.pageData.pageNo,
            rows: this.pageData.rows,
        };
        this.httpService.get(url, reqData).subscribe(data => {
            if (data.success) {
                if(data.result.length>0){
                    data.result.forEach((item,index)=>{
                        //    增加消息类型
                        item["messageType"]=this.getMsgType(item.message);
                    })

                }
                if (data.result.length >= this.pageData.rows) {
                    this.pageData.loadEnd = false;
                } else {
                    this.pageData.loadEnd = true;
                }
                if (this.pageData.pageNo == 1) {
                    this.pageData.clist = data.result;
                } else {
                    // this.pageData.clist = this.pageData.clist.concat(data.result);
                    this.pageData.clist =data.result .concat(this.pageData.clist);
                }
                this.pageData.pageNo++;
                InfiniteScroll && InfiniteScroll.complete();
            } else {
                console.log("从服务器获取聊天记录失败：", data.msg);
            }
            this.isScrolling = false;
        })

    }

    ionViewWillLeave() {
        // unsubscribe
        this.events.unsubscribe('chat:received');
    }

    ionViewDidEnter() {
        //get message list
        /* this.getMsg()
             .then(() => {
                 this.scrollToBottom();
             });*/

        //融云拉取历史记录不可用
        // this.getHistoryMessage();
        // Subscribe to received  new message events
        this.events.subscribe('chat:received', msg => {
            this.pushNewMsg(msg);
        })
    }

    onFocus() {
        this.showEmojiPicker = false;
        this.content.resize();
        this.scrollToBottom();
    }

    //uploadImg
    uploadImg() {
        document.getElementById("userInfoHeader").click();
    }

    /**
     * 图片选中上传
     * @param file
     */
    fileChange(file) {
        // this.thirdPartyApi.uploadImage(file.target.files[0], 'snsImageMsg').subscribe(data => {
        this.thirdPartyApi.uploadImage(file.target.files[0], '').subscribe(imgdata => {
            if (imgdata) {
                console.log("上传图片返回结果:", imgdata);
                //发送图片消息至服务器
                this.sendMessageToServer(null,"ImageMessage",imgdata);
            }
        })
    }

    /**
     * 发送图片消息至服务器
     * @param uploadImgUrl
     */
    sendImageMsg(uploadImgUrl) {

    }

    switchEmojiPicker() {
        this.showEmojiPicker = !this.showEmojiPicker;
        if (!this.showEmojiPicker) {
            this.messageInput.setFocus();
        }
        this.content.resize();
        this.scrollToBottom();
    }

    /**
     * @name getMsg
     * @returns {Promise<ChatMessage[]>}
     */
    getMsg() {
        // Get mock message list
        return this.mainCtrl
            .getMsgList()
            .then(res => {
                this.msgList = res;
            })
            .catch(err => {
                console.log(err)
            })
    }

    getHistoryMessage() {
        //请确保单群聊消息云存储服务开通，且开通后有过收发消息记录
        console.log("RongIMClient:", RongIMClient.getInstance());
        RongIMClient.getInstance().getHistoryMessages(RongIMLib.ConversationType.PRIVATE, this.toUser.id+"",
            1514534742, 20,
            {
                onSuccess: function (list, hasMsg) {
                    // hasMsg为boolean值，如果为true则表示还有剩余历史消息可拉取，为false的话表示没有剩余历史消息可供拉取。
                    // list 为拉取到的历史消息列表
                    console.log("拉取到的历史记录：", list, hasMsg);
                },
                onError: function (error) {
                    // APP未开启消息漫游或处理异常
                    // throw new ERROR ......
                    console.log("拉取到的历史记录错误：", error, error.message);
                }
            });
    }

    /**
     * @name sendMsg
     */
    sendMsg() {
        if (!this.editorMsg.trim()) return;

        // Mock message
        const id = Date.now().toString();
        let newMsg: ChatMessage = {
            messageId: Date.now().toString(),
            userId: this.user.id,
            userName: this.user.name,
            userAvatar: this.user.avatar,
            toUserId: this.toUser.id,
            time: Date.now(),
            message: this.editorMsg,
            status: 'pending'
        };

        this.pushNewMsg(newMsg);
        this.editorMsg = '';

        if (!this.showEmojiPicker) {
            this.messageInput.setFocus();
        }


        this.mainCtrl.sendMsg(newMsg)
            .then(() => {
                let index = this.getMsgIndexById(id);
                if (index !== -1) {
                    this.msgList[index].status = 'success';
                }
            })
    }

    /**
     * 判断消息类型
     * @param msgContent
     */
    getMsgType(msgContent){
        if(msgContent&&msgContent.indexOf("http://snsall.oss-cn-qingdao.aliyuncs.com")!=-1){
            return "ImageMessage";
        }
        return "TextMessage";
    }
    /**
     * 保存消息到服务器
     * @param msgContent
     */
    sendMessageToServer(event,msgType, content) {
        let self = this;
        let msgContent;
        if (msgType == "ImageMessage") {//图片消息
            msgContent = content;
        } else {//文本消息
            console.log("点击发送消息按钮：", event.target.value);
            msgContent = this.editorMsg;
        }
        // 废弃
        const id = Date.now().toString();
        let newMsg: ChatMessage = {
            messageId: Date.now().toString(),
            userId: this.user.id,
            userName: this.user.name,
            userAvatar: this.user.avatar,
            toUserId: this.toUser.id,
            time: new Date().toLocaleString().replace(/:\d{1,2}$/, ' '),
            message: msgContent,
            // status: 'pending'
            status: 'success'
        };
        //判断消息类型
        let mType=this.getMsgType(msgContent);
        let msgObj= {
            "headPic": this.user.avatar,
            "message": msgContent,
            "me": true,
            "messageType":mType,
            timestamp:new Date().toLocaleString().replace(/:\d{1,2}$/, ' '),
            userId: this.user.id,
            toUserId: this.toUser.id
        };

        this.addNewMsg(msgObj);
        if (!this.showEmojiPicker) {
            this.messageInput.setFocus();
        }
        if (msgType == "TextMessage") {
            this.editorMsg = '';
        }

        //  保存消息到服务器
        this.httpService.post(this.httpService.config.host.org + '/sns/history/',
            {
                "toUserId": this.toUser.id, //接收方用户id
                "message": msgContent
            }).subscribe((data) => {
            console.log("保存消息接口服务器返回：", data);
            if (data.success) {
                console.log("保存消息到服务器成功");
                //    调用融云发送消息
                this.sendMessageToRongIM(msgType, msgContent)
            }
        })
    }

    /**
     * 发送消息给融云
     * @param event
     * @param msgType
     */

    sendMessageToRongIM( msgType, msgContent) {

        let extraInfo = {"toUserId": this.toUser.id,"toUserNickName":this.toUser.name,"toUserHeadPic":this.toUser.avatar};
console.log("调用融云，"+this.user.id+"即将发送消息给"+this.toUser.id);
        // 发送消息--使用融云api
        var msg = new RongIMLib.TextMessage({content: msgContent, extra: JSON.stringify(extraInfo)});

        var conversationtype = RongIMLib.ConversationType.PRIVATE; // 单聊,其他会话选择相应的消息类型即可。
        var targetId = this.toUser.id; // 目标 Id
        RongIMClient.getInstance().sendMessage(conversationtype, targetId+"", msg, {
                onSuccess: function (message) {
                    //message 为发送的消息对象并且包含服务器返回的消息唯一Id和发送消息时间戳
                    console.log("融云发送消息成功");
                },
                onError: function (errorCode, message) {
                    var info = '';
                    switch (errorCode) {
                        case RongIMLib.ErrorCode.TIMEOUT:
                            info = '超时';
                            break;
                        case RongIMLib.ErrorCode.UNKNOWN_ERROR:
                            info = '未知错误';
                            break;
                        case RongIMLib.ErrorCode.REJECTED_BY_BLACKLIST:
                            info = '在黑名单中，无法向对方发送消息';
                            break;
                        case RongIMLib.ErrorCode.NOT_IN_DISCUSSION:
                            info = '不在讨论组中';
                            break;
                        case RongIMLib.ErrorCode.NOT_IN_GROUP:
                            info = '不在群组中';
                            break;
                        case RongIMLib.ErrorCode.NOT_IN_CHATROOM:
                            info = '不在聊天室中';
                            break;
                        default :
                            info = "啦啦啦";
                            break;
                    }
                    console.log('发送失败:' + info);
                }
            }
        );
    }

    /**
     * @name pushNewMsg
     * @param msg
     */
    pushNewMsg(msg: ChatMessage) {
        const userId = this.user.id,
            toUserId = this.toUser.id;
        // Verify user relationships
        if (msg.userId == userId && msg.toUserId == toUserId) {
            this.msgList.push(msg);

        } else if (msg.toUserId == userId && msg.userId == toUserId) {
            this.msgList.push(msg);
        }
        this.scrollToBottom();
    }
    addNewMsg(msg) {
        const userId = this.user.id,
            toUserId = this.toUser.id;
        // Verify user relationships
        if (msg.userId == userId && msg.toUserId == toUserId) {
            this.pageData.clist.push(msg);

        } else if (msg.toUserId == userId && msg.userId == toUserId) {
            this.pageData.clist.push(msg);
        }
        this.scrollToBottom();
    }

    getMsgIndexById(id: string) {
        return this.msgList.findIndex(e => e.messageId === id)
    }

    scrollToBottom() {
        setTimeout(() => {
            if (this.content.scrollToBottom) {
                this.content.scrollToBottom();
            }
        }, 400)
    }
}
