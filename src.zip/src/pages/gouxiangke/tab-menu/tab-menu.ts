import { GlobalDataProvider } from './../providers/global-data/global-data.model';
import { Api } from './../providers/api/api';
import { Config } from './../providers/api/config.model';
import {Component, ElementRef, ViewChild} from '@angular/core';
import { App, IonicPage, NavController, NavParams, Tabs, Events } from 'ionic-angular';
/**
 * Generated class for the TabMenuPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-tab-menu',
  templateUrl: 'tab-menu.html',
})
export class TabMenuPage {
    @ViewChild('tabMenus') tabMenus: Tabs;
    @ViewChild('customeMsgTab') customeMsgTab: ElementRef;
    userHomePage;
    userTopicPage;//专题
    userCategoryPage; //分类
    userInfoPage;//个人
    snsUserInfoPage; //消息 
    userCartPage;// STOREAPP=》购物车 

    isShowMenu: any = true;
    index; //tabs 的下标;
  constructor(public navCtrl: NavController, public navParams: NavParams,public app:App,
      private events: Events, public config: Config,public api:Api, public globalDataProvider:GlobalDataProvider) {
      this.index = navParams.get('index');
      //如果是店铺app，保存ID
      window.localStorage.setItem('storeId', this.config.STOREID);
      
      //根据 PLATFORM: any = 'APP'; 判断是什么应用；
      if (this.config.PLATFORM == 'APP') {
          this.userHomePage = "UserHomePage" //主页
          this.userTopicPage = "UserTopicPage" //专题
          this.userCategoryPage = "UserCategoryPage" //分类
          this.userInfoPage = "UserInfoPage" //个人
          this.snsUserInfoPage = "SnsUserInfoPage" //消息
      } else { 
          this.userHomePage = "UserStoreHomePage" //店铺主页
          this.userCartPage = 'UserShoppingCartDetailPage'; //购物车
          this.userCategoryPage = "UserCategoryPage" //分类  
          this.userInfoPage = "UserInfoPage" //个人
      }
      
      

      events.subscribe("leaveSns",()=>{
          console.log("消息一级页面收到leaveSns事件");
          this.isShowMenu=-true;
      });
  }
  ionViewWillEnter(){
        console.log("即将进入底部菜单TabMenu");
      this.isShowMenu=true;
  }
  ionViewWillLeave(){
      setTimeout(()=>{
          this.isShowMenu=false;
      },200);
      // this.isShowMenu=false;
      console.log("即将离开底部菜单TabMenu");
  }
    ionViewDidLoad() {
      
         //获取配置信息
      /**
       * is_allow 是否确认收货
       * is_allow_wholesale 是否批发
       * is_allow_groupon 是否拼团
       * is_allow_proxy 是否代售
       * is_allow_minbuynum 是否最小起批量
       */
      this.api.get(this.api.config.host.bl + '/platformset/selectConfigInfo', {
        nameStr:'is_allow,is_allow_proxy,is_allow_groupon,is_allow_wholesale,is_allow_minbuynum'
      }).subscribe(data => {
        if (data.success) { 
          data.result ? data.result : {};
          this.globalDataProvider.platformsetSelectConfigInfo = data.result;
        }
      })  
    console.log('ionViewDidLoad TabMenuPage');
    let messageMenu=this.tabMenus.getNativeElement();
    let customeMsgEle=this.customeMsgTab.nativeElement;
    // let ele=messageMenu.querySelector("a.tab-button");
    let homeMenuEle=messageMenu.querySelectorAll("a.tab-button")[0];
    let ele=messageMenu.querySelectorAll("a.tab-button")[3];
    console.log("查询到的菜单元素：",messageMenu,homeMenuEle.style,ele,"ele样式：",ele.style,customeMsgEle)
      messageMenu=ele;
    let style;
      if (window.getComputedStyle) {
          style = window.getComputedStyle(homeMenuEle, null);    // 非IE
      } else {
          style = homeMenuEle.currentStyle;  // IE
      }
    //   console.log("首页测量后样式：",style);
    //  屏幕宽度
      let screenWidth=screen.width;
      let menuWidth=parseInt(style.width);
      let spaceWidth=(screenWidth-menuWidth*5)/2;
      customeMsgEle.style.left=menuWidth*3+spaceWidth+"px";
    // let messageMenu=this.tabMenus.getNativeElement();
      customeMsgEle.style.width=menuWidth+"px";
      console.log("首页测量后样式：screenWidth,menuWidth,spaceWidth",screenWidth,menuWidth,spaceWidth);

  }

    /**
     * 点击消息菜单了
     */
    onMessageMenuClick(){

        console.log("进入消息页面");
       // alert("消息按钮被点击了");
        this.events.publish('testClick');
        setTimeout(()=>{
            this.isShowMenu=false;
        },100);


        // this.app.getRootNav().push("SnsPage");
    }

    //监听tabs的change事件
    changeTabs() {
       
    }

    ngAfterViewInit() { 
        setTimeout(() => { 
            if (this.index) { 
                this.tabMenus.select(this.index);
                this.index = '';
            }
        }, 30)
        
    }
}
