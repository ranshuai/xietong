import { CommonModel } from './../../../providers/CommonModel';
import { GlobalDataProvider } from './../providers/global-data/global-data.model';
import { User } from './../providers/user/user';
import { Component, Input, forwardRef, Inject } from '@angular/core';
import { IonicPage, NavController, ViewController } from 'ionic-angular';
import { CommonProvider } from "../providers/common/common";
import { Config } from '../providers/api/config.model';
import { UserSetPage } from './user-set/user-set';
import { UserInfoOrderPage } from './user-info-order/user-info-order';
import { UserInfoCollectionPage } from './user-info-collection/user-info-collection';
import { UserInfoWalletPage } from './user-info-wallet/user-info-wallet';
import { UserInfoAddressPage } from './user-info-address/user-info-address';
import { UserInfoOrderServicesPage } from './user-info-order/user-info-order-services/user-info-order-services';
import { Api } from '../providers/api/api';
import { UserInfoCouponPage } from './user-info-coupon/user-info-coupon';
import { CommonData } from '../providers/user/commonData.model';
import { UserInfoEvaluatePage } from '../user-info/user-info-evaluate/user-info-evaluate';
import { ThirdPartyApiProvider } from "../providers/third-party-api/third-party-api";
import { UserInfoPrepayPage } from "./user-info-prepay/user-info-prepay";

import { Storage } from '@ionic/storage';

// import * as IosSelect from 'IosSelect';
/**
 * Generated class for the UserInfoPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-user-info',
  templateUrl: 'user-info.html',
})
export class UserInfoPage {
  userSetPage = UserSetPage;
  userInfoOrderPage = UserInfoOrderPage;
  userInfoCollectionPage = UserInfoCollectionPage;
  userInfoWalletPage = UserInfoWalletPage;
  userInfoAddressPage = UserInfoAddressPage;
  userInfoOrderServicesPage = UserInfoOrderServicesPage;
  userInfoCouponPage = UserInfoCouponPage;
  userInfo: any;
  userInfoEvaluatePage = UserInfoEvaluatePage;
  userInfoPrepayPage = UserInfoPrepayPage;
  constructor(
    public common: CommonProvider,
    public config: Config,
    public api: Api,
    public nav: NavController,
    public viewCtrl: ViewController,
    public commonData: CommonModel,
    public thirdPartyApi: ThirdPartyApiProvider,
    private user: User,
    public storage: Storage,
    public globalDataProvider: GlobalDataProvider,
    public commonModel:CommonModel
  ) {
  }

  getUserInfo() {
    this.api.get(this.api.config.host.org + 'user/userinfo').subscribe(data => {
      if (data.success) {
        data.result.headPic = data.result.headPic ? data.result.headPic : '../assets/img/deful_headerPic.jpg';

        this.commonModel.TAB_INIT_USERINFO = data.result;
      } else {
        this.common.tostMsg({ msg: data.msg })
      }
    });
  }

  goTouUserSet() {
    this.common.goToPage(this.userSetPage)
  }

  goToPageUserInfoOrder(_type) {
    this.common.goToPage(this.userInfoOrderPage, { type: _type })
  }
  goToPageUserInfoCollection() {
    this.common.goToPage(this.userInfoCollectionPage, {})
  }

  goToPageUserInfoWalletPage() {
    this.common.goToPage(this.userInfoWalletPage, {})
  }

  goToUserInfoAddressPage() {
    this.api.config.isEditor = false;
    this.common.goToPage(this.userInfoAddressPage)
  }

  goToUserInfoOrderServicesPage() {
    this.common.goToPage(this.userInfoOrderServicesPage)

  }

  goToUserInfoCouponPage() {
    this.common.goToPage(this.userInfoCouponPage)
  }

  goToUserInfoEvaluatePage() {
    this.common.goToPage(this.userInfoEvaluatePage)
  }
  goToUserInfoBankPage() {
    this.common.goToPage('UserInfoBankPage')
  }
  goToUserInfoGroupPage() {
    this.common.goToPage('UserInfoGroupPage');
  }
  goToUserInfoPrepayPage() { 
    this.common.goToPage(this.userInfoPrepayPage)
  }


  //提交
  subUserInfo(_data) {
    this.api.post(this.api.config.host.org + '/user/updataUserInfo', {
      nickname: this.commonModel.TAB_INIT_USERINFO.nickname,
      sex: this.commonModel.TAB_INIT_USERINFO.sex,
      headPic: _data,
      birthday: this.commonModel.TAB_INIT_USERINFO.birthday
    }).subscribe(data => {
      if (data.success) {
        this.commonModel.TAB_INIT_USERINFO.headPic = _data;
        this.common.tostMsg({ msg: data.msg })
      } else {
        this.common.tostMsg({ msg: data.msg })
      }
    })
  }

  //uploadImg
  uploadImg() {
    document.getElementById("userInfoHeader").click();
  }

  fileChange(file) {
    this.thirdPartyApi.uploadImage(file.target.files[0], 'user').subscribe(data => {
      if (data) {
        this.subUserInfo(data);
      }
    })
  }

  ionViewDidEnter() {
    window.document.title = this.globalDataProvider.domainNameWX;
    if (this.config.PLATFORM == 'WX') {
      this.getUserInfo();
      return 
     }
     if (this.config.PLATFORM == 'APP'|| this.config.PLATFORM == 'STOREAPP') {
      this.api.getUserId().subscribe(userId => {
        if (!userId) {
          //如果没有userID跳转登陆页面
          this.common.goToPage('PublicLoginPage', {'channelsType':'user'});
        } else {
          this.getUserInfo();
           //从storage中取storeId
        }
      });
      return 
     }

    
  }

}
