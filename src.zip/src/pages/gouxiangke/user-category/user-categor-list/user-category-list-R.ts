import { GlobalDataProvider } from './../../providers/global-data/global-data.model';
import { GoodsDetailPage } from './../../user-common/goods-detail/goods-detail';
import { Component, Input,ViewChild } from '@angular/core';
import { LoadingController,Content } from "ionic-angular";
import { CommonProvider } from "../../providers/common/common";
import { RequestOptions, Headers } from '@angular/http';
import { Api } from '../../providers/api/api';
import { ShoppingCart } from "../../providers/user/shopping-cart";
import { Config } from '../../providers/api/config.model'
/**
 * Generated class for the UserTopicListPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'user-category-list-R',
  templateUrl: 'user-category-list-R.html',
})
export class UserCategoryListRComponent {
  @Input() public data: any;
  @Input() public catId: any;
  @Input() public loadEnd: any;
  config = {
    pageNo: 1,
    row: 10
  } 
  @ViewChild(Content) content: Content;  
  constructor(public common: CommonProvider, public api: Api, public loadingCtrl: LoadingController, private shoppingCart: ShoppingCart,public configProviders:Config,public globalDataProvider:GlobalDataProvider) { 
  }
  ngOnChanges() {
    this.config.pageNo = 1;
      if (this.content) { 
      this.content.scrollTo(0, 0,0);
        
      }
      if ((this.data && this.data.length) >= 10) {
      this.loadEnd = false;
    } else { 
      this.loadEnd = true;
    }
  }
  goodsDetailPage = GoodsDetailPage;
  getList(json, refresher?) { 
    this.api.post(this.api.config.host.bl + 'v2/goods/queryGoodsList', json).subscribe(data => {
      if (data.success) {
        if (data.result.length < 10) {
          this.loadEnd = true;
        } else { 
          this.loadEnd = false;
        }
        if (json.pageNo == 1) {
          this.data = data.result;
        } else { 
          this.data = this.data.concat(data.result)
        }
      }
      refresher && refresher.complete();
    })
  }

  goToGoodsListPage(id){
  	console.log(id);
    this.common.goToPage('GoodsListPage', { catId:id});
  }

  refresh(refresher) { 
    this.config.pageNo = 1;
    this.getList({ cateId: this.catId,pageNo:1,rows:10 },refresher);
  }
  //下拉加载
  doInfinite(InfiniteScroll) {
    this.config.pageNo ++;
    this.getList({ cateId: this.catId,pageNo:this.config.pageNo,rows:10 },InfiniteScroll);
  }

  goToGoodsDetailPage(item) {
    let goodsId = item.goods_id || item.goodsId;
    console.log(goodsId);
    this.common.goToPage(this.goodsDetailPage, { goods_id:goodsId });
  }

  //添加购物车
  addCart(event, item) {
    let loading = this.loadingCtrl.create({ dismissOnPageChange: true, content: '添加中，请稍后...' });
    loading.present();
    //获取商品详情
    let goodsId = item.goods_id || item.goodsId;
    this.api.get(this.api.config.host.bl + 'v2/goods/detail/' + goodsId).subscribe(data => {
      if (data.success) {
        let goodsInfo = data.result;
        this.shoppingCart.add({
          goodsId: goodsInfo.goodsId,
          goodsSpec: goodsInfo.tpSpecGoodsPrices.key_,
          goodsNum: 1,
        }).subscribe(_ => {
          loading.dismiss();
        });
      } else {
        loading.dismiss();
        this.common.showToast('加入购物车失败,请稍后再试');
      }
    });
    event.stopPropagation();
  }
}
