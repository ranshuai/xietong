import { Component } from '@angular/core';
/**
 * Generated class for the GoodsSpecsSelectBarComponent component.
 *
 * See https://angular.io/docs/ts/latest/api/core/index/ComponentMetadata-class.html
 * for more info on Angular Components.
 */
@Component({
  selector: 'goods-specs-select-bar',
  templateUrl: 'goods-specs-select-bar.html'
})
export class GoodsSpecsSelectBarComponent {

  constructor() { }

}
