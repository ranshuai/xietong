export class Config {
  // domain = 'jiuhui' 92E21DE17C0CE872; //备用domain会从headers中获取
  domain = "92E21DE17C0CE872"//购享客-JAVA
  // domain = "92E21DE17C0CE872"//独角鲸冻采
  // domain = "6B8E218337401D22"//首鲜汇-JAVA
  // domain = "39907C2EEC3FDFD9"//财税家
  //  domain = "D28ED5E578CFCBBE"//麻城同城
    type = '1';//1是域 2是店铺
    platform = 'android';//android  ios  wx web


  // domain = 'F6CE0C446574270D'; //租赁商城

  // domain = 'gxk'; //备用domain会从headers中获取
  // storeId = 4;
  clientType = 1;
  hostList = {
    //正式环境
    prod: {
      bl: 'https://b.snsall.com/',
      lg: 'https://l.snsall.com/',
      org: 'https://o.snsall.com/'
    },
    //测试环境
    test: {
      bl: 'https://t.b.snsall.com/',
      lg: 'https://t.l.snsall.com/',
      org: 'https://t.o.snsall.com/'
    },
    //开发环境
    dev: {
      bl: 'http://d.b.snsall.com/',
      lg: 'http://d.l.snsall.com/',
      org: 'http://d.o.snsall.com/'
    }
  };

  //测试环境,会根据headers中的数据，来切换
  host = this.hostList.test;

  timeout = 30 * 1000;
  timeout_long = 60 * 1000;
  version = '1.0.10';
  real: boolean = false;
  isEditor: boolean = false;
  interva = {
    "login": 60,
    "register": 60
  };
    //店铺和商城的配置信息
  CONFINFO: {
    type: 1, //商城是1， 店铺是 2
  };
  //平台 platform 域商城 app, 店铺App STOREAPP，域商城微信 WX，店铺微信 STOREAPP
  PLATFORM: any = 'STOREAPP';

  STOREID: any = 1415;//店铺ID 1415 域商城 STOREID: any

  //平台类型
  PLATFORMTYPE: any = '';
}



