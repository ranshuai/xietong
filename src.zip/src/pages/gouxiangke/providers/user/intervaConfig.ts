export class IntervaConfig{ 
  modifyPassword: any = 60;
  modifyMobile: any = 60;
  walletRecharge: any = 60;
  walletWithdrawals:any = 60;
}