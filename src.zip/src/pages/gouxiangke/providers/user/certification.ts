export class Certification{ 
  real: boolean = false;//用户是否实名认证
  identity: any;
}