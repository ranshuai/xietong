import { MainCtrl } from './../../../../providers/MainCtrl';
import { Component } from '@angular/core';
import { NavController, NavParams,IonicPage, LoadingController } from 'ionic-angular';

/**
 * Generated class for the ApplyLogisticsSuccessPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-apply-logistics-success',
  templateUrl: 'apply-logistics-success.html',
})
export class ApplyLogisticsSuccessPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, private mainCtrl: MainCtrl) {
  }

  go(){
    if (this.mainCtrl.httpService.config.platform == 'android' || this.mainCtrl.httpService.config.platform == 'WX') {
      this.mainCtrl.setRootPage('TabMenuPage');
     }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ApplyLogisticsSuccessPage');
  }

}
