import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChangeroleTabsPage } from './changerole-tabs';

@NgModule({
  declarations: [
    ChangeroleTabsPage,
  ],
  imports: [
    IonicPageModule.forChild(ChangeroleTabsPage),
  ],
})
export class ChangeroleTabsPageModule {}
