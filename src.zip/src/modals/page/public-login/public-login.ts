import { CommonProvider } from './../../../pages/gouxiangke/providers/common/common';
import { NativeService } from './../../../providers/NativeService';
import { HttpService } from './../../../providers/HttpService';
import { MainCtrl } from './../../../providers/MainCtrl';
import { Component } from '@angular/core';
import { Events, IonicPage, NavController, NavParams, App, LoadingController } from 'ionic-angular';
import { CommonModel } from "../../../providers/CommonModel";

/**
 * Generated class for the PublicLoginPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-public-login',
  templateUrl: 'public-login.html',
})
export class PublicLoginPage {
  //默认登录方式
  loginType = "phone";
  isend: boolean = false;
  //密码显示隐藏字段
  showPassword = "password";

  imgCodeFlag: boolean = false;
  //图片验证码信息
  imgCode = {
    'img': undefined,
    'error': false,
    'codeName': undefined
  };
  //表单对象
  pageData = {
    imageCode: "",
    mobile: "",
    msgCode: "",
    password: "",
    uuid: this.mainCtrl.httpService.config.uuid,
  }
  //获取验证码定时器
  timeInterval;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private mainCtrl: MainCtrl,
    private httpService: HttpService,
    private nativeService: NativeService,
    public commonModel: CommonModel,
    public events: Events,
    private appCtrl: App,
    private loadingCtrl: LoadingController,
    public commonProvider:CommonProvider
  ) {
    this.getImgCode();
  }

  /**
   * 切换登录方式
   */
  changeLogin(_type) {
    this.loginType = _type;
    let mobile = this.pageData.mobile;
    this.pageData = {
      imageCode: "",
      mobile: mobile,
      msgCode: "",
      password: "",
      uuid: this.mainCtrl.httpService.config.uuid
    }
  }
  //显示密码
  showPassWord() {
    this.showPassword = this.showPassword == 'password' ? 'text' : 'password';
  }

  /**获取图形验证码 */
  getImgCode() {
    this.imgCode.error = false;
    this.httpService.get(this.httpService.config.host.org + '/v2/user/getImageCode', { uuid: this.httpService.config.uuid }).subscribe(data => {
      if (data.success) {
        this.imgCode.img = data.result.img;
        this.imgCode.codeName = data.result.codeName;
        this.checkImgCode();
        console.log(this.imgCode)
      } else {
        this.imgCode.error = true;
      }
    });
  }

  checkImgCode() {
    if (this.pageData.imageCode != this.imgCode.codeName) {
      this.imgCodeFlag = true;
    } else {
      this.imgCodeFlag = false;
    }
  }

  /**获取手机验证码 */
  getPhoneCode() {
    if (this.pageData.imageCode == '' || this.pageData.mobile == '') {
      this.mainCtrl.nativeService.showToast('图形验证码和手机号必填')
    } else {
      if (this.pageData.mobile.match(/^[0-9]+$/) == null || this.pageData.mobile.length < 11) {
        this.nativeService.showToast("请输入手机号正确格式")
      } else {
        if (this.imgCodeFlag == true) {
          this.nativeService.showToast("图形验证码错误")
        } else {
          if (!this.isend && this.mainCtrl.commonModel.interva.login == 60) {
            this.isend = true;
            this.httpService.get(this.httpService.config.host.org + 'v2/user/getPhoneCode1', {
              imageCode: this.pageData.imageCode,
              mobile: this.pageData.mobile,
              uuid: this.httpService.config.uuid
            }).subscribe(data => {
              if (data.success) {
                clearInterval(this.timeInterval);
                this.timeInterval = setInterval(() => {
                  if (this.mainCtrl.commonModel.interva.login != 0) {
                    this.mainCtrl.commonModel.interva.login--;
                  } else {
                    this.mainCtrl.commonModel.interva.login = 60;
                    this.isend = false;
                    clearInterval(this.timeInterval);
                  }
                }, 1000);
                this.nativeService.showToast(data.msg);
              } else {
                this.nativeService.showToast(data.msg || "网络连接异常")
                this.isend = false;
                this.getImgCode();
              }
            });
          }
        }
      }
    }
  }

  login() {
    let url = this.loginType == "phone" ? this.httpService.config.host.org + 'v2/user/login' : this.httpService.config.host.org + 'v2/user/loginpwd';
    this.httpService.post(url, this.pageData).subscribe(data => {
      if (data.success) {
        this.mainCtrl.commonModel.userId = data.result.userId;
        this.getUserInfo();
       
        //获取用户信息
      } else {
        this.nativeService.showToast(data.msg);

      }
    })
  }


  /**
   * 
   * @param type 登录类型
   */
  thirdPartyLogin(type) {
    let loading = this.loadingCtrl.create({
      dismissOnPageChange: true,
      showBackdrop: false, //是否显示遮罩层
      content: '加载中...'
    });
    loading.present();
    if (this.mainCtrl.nativeService.isMobile()) {

    } else {
      //h5第三方登录
      switch (type) {
        case 'wechat':
          this.mainCtrl.getWechatImpower().subscribe(data => {
            loading.dismiss();
            if (data.success) {
              window.location.href = data.url;
            } else {
              this.mainCtrl.nativeService.showToast(data.msg||'网络链接异常')
            }
          })
          break;
      }
    }
  }

  getUserInfo() {
    this.httpService.get(this.httpService.config.host.org + 'user/userinfo').subscribe(data => {
      if (data.success) {
        window.localStorage.setItem('userId', data.result.userId);
        
        data.result.headPic = data.result.headPic ? data.result.headPic : '../assets/img/deful_headerPic.jpg';
        this.mainCtrl.commonModel.TAB_INIT_USERINFO = data.result;
         //获取融云token
         this.navCtrl.popToRoot();
      } else {
        this.mainCtrl.nativeService.showToast(data.msg)
      }
    });
  }
}
