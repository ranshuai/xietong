import { Directive, ElementRef, Input } from '@angular/core';


@Directive({
  selector: '[showPassicon]', // Attribute selector
  host: {
    '(click)': 'showPassIcon($event)'
  }
})
export class ShowPassiconDirective {

  @Input() showPassicon;

   element: ElementRef;

  constructor(element: ElementRef) {
    this.element = element;
  }
  
  showPassIcon() { 
    // this.element.nativeElement.setAttribute('class','icon icon-ios ion-ios-eye-outline lixiaofie');
    let inputItem = this.element.nativeElement.parentNode.parentNode.getElementsByTagName('input')[0];
    let iconClass = this.element.nativeElement.getAttribute('class');
    if (inputItem.getAttribute('type') == 'password') {
      inputItem.setAttribute('type', 'text');
      iconClass=iconClass.replace('apollo-icon-34', 'ion-ios-eye-outline');
      
    } else { 
      inputItem.setAttribute('type', 'password');
      iconClass=iconClass.replace('ion-ios-eye-outline', 'apollo-icon-34')
    }
      this.element.nativeElement.setAttribute('class', iconClass);
    
  }

}
